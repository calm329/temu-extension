import React from 'react';
import '@pages/options/Options.css';

const Options: React.FC = () => {
  return <div className="container">Options</div>;
};

export default Options;
