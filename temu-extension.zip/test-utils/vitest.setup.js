// Do what you need to set up your test
console.log('setup test: vitest.setup.js');
